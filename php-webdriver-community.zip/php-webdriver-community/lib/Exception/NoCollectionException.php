<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Removed in W3C WebDriver
 */
class NoCollectionException extends WebDriverException
{
}
